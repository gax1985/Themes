Dotfiles is developed and maintained by the following folks:

- Jon Bernard
- Anaël Beutot
- Remco Wendt
- Sebastian Rahlf
- Reinout van Rees
- Daniel Harding
- Gary Oberbrunner
- Alexandre Rossi
- Luper Rouch
- Jesús García Crespo
- Jay Sweeney
- Alexandre Viau
- Michael Barrett
- Ivan Malison
- David Beitey
- David Lozano Jarque
